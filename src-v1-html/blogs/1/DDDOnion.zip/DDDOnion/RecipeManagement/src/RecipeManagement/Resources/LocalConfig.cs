namespace RecipeManagement.Resources;

public static class LocalConfig
{
    public const string IntegrationTestingEnvName = "LocalIntegrationTesting";
    public const string FunctionalTestingEnvName = "LocalFunctionalTesting";
}