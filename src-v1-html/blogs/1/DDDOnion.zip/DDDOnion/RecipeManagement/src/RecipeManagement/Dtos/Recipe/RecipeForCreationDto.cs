namespace RecipeManagement.Dtos.Recipe;

using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

public class RecipeForCreationDto : RecipeForManipulationDto
{

}